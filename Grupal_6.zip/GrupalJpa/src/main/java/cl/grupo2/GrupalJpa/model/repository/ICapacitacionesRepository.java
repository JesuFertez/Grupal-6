package cl.grupo2.GrupalJpa.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.grupo2.GrupalJpa.model.entity.Capacitacion;

public interface ICapacitacionesRepository  extends JpaRepository<Capacitacion,Integer>{

}

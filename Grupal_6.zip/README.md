# Grupal-6
Grupal JPA 
